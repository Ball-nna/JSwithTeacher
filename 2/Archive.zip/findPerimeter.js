//1
function findPerimeter(length, width) {
	return (length+width)*2
}
console.log("ข้อที่ : 1")
console.log(findPerimeter(6,7))
console.log(findPerimeter(20,10))
console.log(findPerimeter(2,9))

//2
function equaTion(num){
    return eval(num)
}
console.log("ข้อที่ : 2")
console.log(equaTion("1+1"))
console.log(equaTion("7*4-2"))
console.log(equaTion("1+1+1+1+1"))