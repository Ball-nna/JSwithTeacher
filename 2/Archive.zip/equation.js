function equaTion(num){
    return eval(num)
}
console.log(equaTion("1+1"))
console.log(equaTion("7*4-2"))
console.log(equaTion("1+1+1+1+1"))
